// popup.js — WiFi Odds popup logic (no inline scripts, MV3 CSP safe)
// v1.1: flights are sorted by odds, show departure times found on the page, and
// clicking a row scrolls the united.com tab to that flight.

var fromEl = document.getElementById("usl-from");
var toEl = document.getElementById("usl-to");
var formEl = document.getElementById("usl-form");
var goEl = document.getElementById("usl-go");
var statusEl = document.getElementById("usl-status");
var resultsEl = document.getElementById("usl-results");
var airlineEl = document.getElementById("usl-airline");
var creditEl = document.getElementById("usl-credit");
var fullLinkEl = document.getElementById("usl-full-link");

var activeTab = null;      // active browser tab (if united.com/alaskaair.com with a route)
var tabRoute = null;       // {o,d} parsed from that tab
var pageFlights = {};      // fn -> times string, as found on the page
var lastData = null, lastO = null, lastD = null;

/* ── per-airline routing (1.6) ── */
var TRACKER_HOST = { UA: "unitedstarlinktracker.com", AS: "alaskastarlinktracker.com" };
// wifiodds.com is a single site now (the per-airline pages 301 to the homepage),
// so every "more on wifiodds" link points at the homepage.
var WIFIODDS_URL = { UA: "https://wifiodds.com/", AS: "https://wifiodds.com/" };
var ALASKA_ORIGINS = ["https://www.alaskaair.com/*", "https://alaskaair.com/*"];
// Google Flights lives at www.google.com/travel/flights. Chrome grants optional
// host permissions per ORIGIN, so the request has to be the whole origin — the
// injection itself is narrowed to /travel/* by the dynamic registration in
// bg.js, and content.js narrows again to flights search/results pages. Say so
// on the button's tooltip: users are (rightly) wary of "all of google.com".
var GFLIGHTS_ORIGINS = ["https://www.google.com/*"];

function airline() {
  var v = airlineEl && airlineEl.value ? airlineEl.value.toUpperCase() : "UA";
  return TRACKER_HOST[v] ? v : "UA";
}
function setAirline(a) {
  a = TRACKER_HOST[String(a || "").toUpperCase()] ? String(a).toUpperCase() : "UA";
  if (airlineEl) airlineEl.value = a;
  updateCredit();
  return a;
}
function updateCredit() {
  if (creditEl) creditEl.textContent = "data: " + TRACKER_HOST[airline()];
  if (fullLinkEl) fullLinkEl.href = WIFIODDS_URL[airline()];
}

function pctClass(p) {
  if (p >= 50) return "usl-pct-hi";
  if (p >= 35) return "usl-pct-mid";
  if (p >= 20) return "usl-pct-low";
  return "usl-pct-no";
}

function el(tag, className, text) {
  var e = document.createElement(tag);
  if (className) e.className = className;
  if (text !== undefined && text !== null) e.textContent = text;
  return e;
}

function clearResults() { resultsEl.innerHTML = ""; }
function setStatus(text) { statusEl.textContent = text || ""; }

function sameRoute(o, d) {
  return tabRoute && tabRoute.o === o && tabRoute.d === d;
}

function jumpTo(fn) {
  if (!activeTab) return;
  chrome.tabs.sendMessage(activeTab.id, { type: "gotoFlight", fn: fn }, function () {
    void chrome.runtime.lastError;
    window.close();
  });
}

function renderFlights(flights, o, d) {
  var top = flights.slice(0, 8);
  if (!top.length) return null;
  var onPage = sameRoute(o, d) && Object.keys(pageFlights).length > 0;
  var wrap = el("div", null);
  wrap.appendChild(el("div", "usl-section-label",
    onPage ? "Flights — highest odds first · click to jump to it on the page" : "Flights — highest odds first"));
  top.forEach(function (f, i) {
    var row = el("div", "usl-flight-row");
    var left = el("div", "usl-flight-left");
    if (i === 0) left.appendChild(el("span", "usl-star", "⭐"));
    left.appendChild(el("span", null, f.fn));
    var times = pageFlights[f.fn];
    if (times) left.appendChild(el("span", "usl-time", times));
    var right = el("div", "usl-flight-right");
    right.appendChild(el("span", "usl-pct " + pctClass(f.prob), f.prob + "%"));
    right.appendChild(el("span", "usl-obs", f.obs + " obs"));
    row.appendChild(left);
    row.appendChild(right);
    if (times !== undefined && onPage) {
      // Keyboard-operable jump row (Codex P2-05): native-button semantics on the
      // div — Tab reaches it, Enter/Space jump exactly like a click.
      row.classList.add("usl-clickable");
      row.setAttribute("role", "button");
      row.tabIndex = 0;
      row.setAttribute("aria-label", "Jump to " + f.fn + " on the page");
      row.title = "Scroll the booking tab to " + f.fn;
      var jump = function () { jumpTo(f.fn); };
      row.addEventListener("click", jump);
      row.addEventListener("keydown", function (ev) {
        if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); jump(); }
      });
    } else if (onPage) {
      row.classList.add("usl-ghost");
      row.setAttribute("aria-disabled", "true");
      row.tabIndex = -1;
      row.title = "Not operating in these results (odds are route history)";
      left.appendChild(el("span", "usl-time", "not in these results"));
    }
    wrap.appendChild(row);
  });
  return wrap;
}

function renderItins(itins) {
  var top = itins.slice(0, 3);
  if (!top.length) return null;
  var wrap = el("div", null);
  wrap.appendChild(el("div", "usl-section-label", "Best itineraries"));
  top.forEach(function (it) {
    var path = (it.via && it.via.length ? it.via : []).join(" → ");
    // The joint % rides the SAME ramp/pill as flight odds (pctClass), not plain
    // text — one consistent scale on every surface.
    var row = el("div", "usl-itin-row");
    row.style.display = "flex";
    row.style.alignItems = "center";
    row.style.justifyContent = "space-between";
    row.style.gap = "8px";
    row.appendChild(el("span", null, (path ? path + " · " : "") + it.hours + "h"));
    row.appendChild(el("span", "usl-pct " + pctClass(it.joint), it.joint + "%"));
    wrap.appendChild(row);
  });
  return wrap;
}

function renderDeps(deps) {
  var top = deps.slice(0, 4);
  if (!top.length) return null;
  var wrap = el("div", null);
  wrap.appendChild(el("div", "usl-section-label", "Confirmed departures (next ~72h)"));
  top.forEach(function (d) {
    var text = d.fn + " · " + d.date + " " + d.time + "Z · " + d.tail;
    wrap.appendChild(el("div", "usl-dep-row", text));
  });
  return wrap;
}

function renderEmpty(o, d) {
  var wrap = el("div", "usl-empty");
  wrap.appendChild(document.createTextNode("No direct-flight Starlink history yet for this route. More at "));
  // United consolidates to wifiodds.com; Alaska keeps its own data source, the
  // same split the injected panel uses.
  var link = el("a", null, airline() === "AS" ? "alaskastarlinktracker.com" : "wifiodds.com");
  link.href = airline() === "AS" ? "https://alaskastarlinktracker.com/" : "https://wifiodds.com/";
  link.target = "_blank";
  link.rel = "noopener";
  wrap.appendChild(link);
  wrap.appendChild(document.createTextNode("."));
  return wrap;
}

// Alaska's route tool answers with a prose summary instead of a flight table.
function renderNote(note) {
  if (!note) return null;
  var wrap = el("div", "usl-empty", note);
  wrap.appendChild(document.createTextNode(" · data: " + TRACKER_HOST[airline()]));
  return wrap;
}

function renderResults(o, d, data) {
  clearResults();
  var any = false;
  var flightsBlock = renderFlights(data.flights || [], o, d);
  if (flightsBlock) { resultsEl.appendChild(flightsBlock); any = true; }
  var itinsBlock = renderItins(data.itins || []);
  if (itinsBlock) { resultsEl.appendChild(itinsBlock); any = true; }
  var depsBlock = renderDeps(data.deps || []);
  if (depsBlock) { resultsEl.appendChild(depsBlock); any = true; }
  var noteBlock = renderNote(data.note);
  if (noteBlock) { resultsEl.appendChild(noteBlock); any = true; }
  if (!any) resultsEl.appendChild(renderEmpty(o, d));
}

function loadPageFlights(o, d) {
  if (!activeTab || !sameRoute(o, d)) return;
  chrome.tabs.sendMessage(activeTab.id, { type: "flightsOnPage" }, function (resp) {
    if (chrome.runtime.lastError || !resp || !resp.flights) return;
    pageFlights = {};
    resp.flights.forEach(function (f) { pageFlights[f.fn] = f.times || ""; });
    if (lastData) renderResults(lastO, lastD, lastData); // re-render with times + clickability
  });
}

function loadRoute(o, d) {
  o = (o || "").toUpperCase().trim();
  d = (d || "").toUpperCase().trim();
  if (o.length !== 3 || d.length !== 3) {
    setStatus("Enter two 3-letter airport codes.");
    return;
  }
  fromEl.value = o;
  toEl.value = d;
  goEl.disabled = true;
  updateCredit();
  setStatus("Loading " + airline() + " " + o + " → " + d + "…");
  clearResults();

  chrome.runtime.sendMessage({ type: "routeData", o: o, d: d, airline: airline() }, function (res) {
    goEl.disabled = false;
    if (chrome.runtime.lastError || !res) {
      setStatus("Could not reach the extension background page.");
      return;
    }
    lastData = res; lastO = o; lastD = d;
    if (!res.ok) {
      setStatus(res.error ? "Error: " + res.error : "No data available yet.");
      renderResults(o, d, res);
      return;
    }
    setStatus(res.cached ? "Cached result" : "Fresh result");
    renderResults(o, d, res);
    loadPageFlights(o, d);
  });
}

// Route + airline from the active tab's URL. united.com and alaskaair.com both
// carry the O/D pair in the query string (under different param names).
function parseTabUrl(url) {
  try {
    var u = new URL(url);
    var params = u.searchParams;
    var o, d;
    if (/(^|\.)united\.com$/.test(u.hostname)) {
      o = params.get("f") || params.get("origin") || params.get("Origin");
      d = params.get("t") || params.get("destination") || params.get("Destination");
      if (o && d) return { o: o.toUpperCase(), d: d.toUpperCase(), airline: "UA" };
      return null;
    }
    if (/(^|\.)alaskaair\.com$/.test(u.hostname)) {
      o = params.get("O") || params.get("o") || params.get("origin") || params.get("from");
      d = params.get("D") || params.get("d") || params.get("destination") || params.get("to");
      // Still worth flagging the tab as Alaska even with no parsable route: the
      // content script may know the route from the page itself.
      if (o && d) return { o: o.toUpperCase(), d: d.toUpperCase(), airline: "AS" };
      return { o: null, d: null, airline: "AS" };
    }
    return null;
  } catch (e) {
    return null;
  }
}

fromEl.addEventListener("input", function () {
  fromEl.value = fromEl.value.toUpperCase().replace(/[^A-Z]/g, "");
});
toEl.addEventListener("input", function () {
  toEl.value = toEl.value.toUpperCase().replace(/[^A-Z]/g, "");
});

formEl.addEventListener("submit", function (e) {
  e.preventDefault();
  loadRoute(fromEl.value, toEl.value);
});

function init() {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    var tab = tabs && tabs[0];
    var urlRoute = tab && tab.url ? parseTabUrl(tab.url) : null;
    syncEnableButton(tab);
    syncGFlightsButton(tab);
    if (!urlRoute) {
      setStatus("Enter a route to check Starlink odds.");
      return;
    }
    activeTab = tab;
    setAirline(urlRoute.airline);
    // Ask the content script which leg is actually being shown (round trips:
    // the URL still says outbound while the RETURN list is on screen).
    chrome.tabs.sendMessage(tab.id, { type: "pageContext" }, function (pc) {
      void chrome.runtime.lastError;
      if (pc && pc.airline) setAirline(pc.airline);
      var route = pc && pc.o && pc.d ? { o: pc.o, d: pc.d } : urlRoute;
      if (!route.o || !route.d) {
        setStatus("Enter a route to check Starlink odds.");
        return;
      }
      tabRoute = { o: route.o, d: route.d };
      loadRoute(route.o, route.d);
    });
  });
}

/* ── optional alaskaair.com permission ─────────────────────────────────────
 * chrome.permissions.request() only works from a user gesture, so it lives on
 * a popup button. Granting fires permissions.onAdded in the service worker,
 * which registers content.js on alaskaair.com (syncDynamicScripts). */
/* THE COVERAGE BOARD. Four hosts, each showing whether the extension can
 * actually run there right now.
 *
 * united.com and app.navan.com are `always: true` because they are static
 * `content_scripts.matches` entries in manifest.json — granted at install and
 * not revocable from here. That is a fact about the manifest, not an optimism:
 * if either is ever moved to an optional permission this flag has to move with
 * it, or the board starts publishing a "ready" nobody granted.
 *
 * Alaska and Google Flights are optional origins, so their state is READ from
 * chrome.permissions.contains on every render. Nothing here caches a grant. */
var HOSTS = [
  { key: "united", label: "united.com", always: true },
  { key: "navan", label: "app.navan.com", always: true },
  { key: "alaska", label: "alaskaair.com", origins: ALASKA_ORIGINS,
    granted: "Enabled on alaskaair.com — reload the tab to see badges.",
    denied: "alaskaair.com access not granted.",
    title: "Chrome asks for alaskaair.com. Reload the tab after granting." },
  { key: "gflights", label: "Google Flights", origins: GFLIGHTS_ORIGINS,
    granted: "Enabled on Google Flights — reload the tab to see ConnectScore chips.",
    denied: "Google Flights access not granted.",
    title: "Chrome asks for all of www.google.com because permissions are " +
      "per-site. The extension only ever runs on google.com/travel/flights " +
      "search results — never on Search, Gmail, or any checkout page." },
];

var hostsEl = document.getElementById("usl-hosts");
var setupEl = document.getElementById("usl-setup");

function drawHosts(state) {
  if (!hostsEl) return;
  hostsEl.textContent = "";
  var pending = 0;
  HOSTS.forEach(function (h) {
    var on = h.always || state[h.key] === true;
    if (!on) pending++;
    var cell = document.createElement("div");
    cell.className = "usl-host " + (on ? "usl-host--on" : "usl-host--off");
    var name = document.createElement("div");
    name.className = "usl-host-n";
    name.textContent = h.label;
    cell.appendChild(name);
    if (on) {
      var s = document.createElement("div");
      s.className = "usl-host-s";
      s.textContent = "ready";
      cell.appendChild(s);
    } else {
      // A real <button>, because chrome.permissions.request() needs a user
      // gesture and only a focusable control gives keyboard users one.
      var b = document.createElement("button");
      b.className = "usl-host-b";
      b.type = "button";
      b.textContent = "grant access";
      if (h.title) b.title = h.title;
      b.addEventListener("click", function () { askFor(h); });
      cell.appendChild(b);
    }
    hostsEl.appendChild(cell);
  });
  // "Finish setup" is onboarding, so it retires itself once there is nothing
  // left to finish rather than nagging about a done job.
  if (setupEl) setupEl.hidden = pending === 0;
}

function askFor(h) {
  try {
    chrome.permissions.request({ origins: h.origins }, function (granted) {
      void chrome.runtime.lastError;
      setStatus(granted ? h.granted : h.denied);
      if (granted && h.key === "alaska") setAirline("AS");
      syncHosts();
    });
  } catch (e) {
    setStatus("Could not request permission.");
  }
}

function syncHosts() {
  if (!hostsEl) return;
  if (!chrome.permissions) { drawHosts({}); return; }
  var state = {};
  var left = 0;
  HOSTS.forEach(function (h) { if (!h.always) left++; });
  if (!left) { drawHosts(state); return; }
  HOSTS.forEach(function (h) {
    if (h.always) return;
    chrome.permissions.contains({ origins: h.origins }, function (granted) {
      void chrome.runtime.lastError;
      state[h.key] = !!granted;
      if (--left === 0) drawHosts(state);
    });
  });
}

function syncEnableButton(tab) { void tab; syncHosts(); }

/* Google Flights used to have its own button and its own sync function, with
 * the same gesture-bound request shape as Alaska. Both hosts now render through
 * the coverage board above, so this is the board's callers keeping their old
 * names rather than a second implementation. */
function syncGFlightsButton(tab) { void tab; syncHosts(); }
syncHosts();

if (airlineEl) airlineEl.addEventListener("change", function () {
  updateCredit();
  if (fromEl.value.length === 3 && toEl.value.length === 3) loadRoute(fromEl.value, toEl.value);
});

updateCredit();
init();


/* ── ConnectScore by airline (v2.0) ────────────────────────────────────────
 * Fully static: every number comes from airlines.js, which is loaded ahead of
 * this file and makes no network calls. Rendered lazily the first time the
 * <details> is opened, so a popup that never opens it pays nothing. If
 * airlines.js is ever missing, the section simply stays empty — no throw. */
var csEl = document.getElementById("usl-cs");
var csListEl = document.getElementById("usl-cs-list");
var csMethodEl = document.getElementById("usl-cs-method");
var csRendered = false;

function csFleetText(a) {
  var fleet = a.fleet ? a.equipped + "/" + a.fleet : "fleetwide";
  return a.systemLabel + " " + fleet;
}

function renderConnectScores() {
  if (csRendered || !csListEl) return;
  if (typeof rankAirlines !== "function") return; // airlines.js absent — stay quiet
  csRendered = true;

  rankAirlines().forEach(function (a) {
    var row = el("div", "usl-cs-row");
    var head = el("div", "usl-cs-head");

    var name = el("div", "usl-cs-name", a.name);
    name.appendChild(el("span", "usl-cs-meta", csFleetText(a)));

    var right = el("div", null);
    right.style.display = "flex";
    right.style.alignItems = "baseline";
    right.appendChild(el("span", "usl-cs-chip " + a.cls, String(a.score)));
    right.appendChild(el("span", "usl-cs-label", a.label));

    head.appendChild(name);
    head.appendChild(right);
    row.appendChild(head);

    var note = el("div", "usl-cs-note", a.note);
    if (a.instrumented) {
      note.appendChild(document.createTextNode(" "));
      note.appendChild(el("span", "usl-cs-live", "· live per-flight odds ↑ above"));
    } else if (a.tracker) {
      // Tracked upstream but coarse-only (Hawaiian: aircraft-type derived, no
      // per-flight probability published) — credit the source, promise nothing.
      note.appendChild(document.createTextNode(" "));
      note.appendChild(el("span", "usl-cs-meta",
        "· data: " + a.tracker + (a.typeDerivedOnly ? " (by aircraft type — no per-flight odds)" : "")));
    }
    row.appendChild(note);
    row.title = a.note;
    // Hover reveals the note on a mouse; tap toggles it on a trackpad/touch.
    row.addEventListener("click", function () { row.classList.toggle("usl-open"); });

    csListEl.appendChild(row);
  });

  if (csMethodEl) {
    csMethodEl.textContent = typeof SCORE_METHOD_LINE === "string" ? SCORE_METHOD_LINE : "";
    if (typeof SCORE_CAVEAT === "string") csMethodEl.title = SCORE_CAVEAT;
  }
}

if (csEl) csEl.addEventListener("toggle", function () { if (csEl.open) renderConnectScores(); });

/* ── Trip monitor (v1.4) ── */
var tripsEl = document.getElementById("usl-trips");
var watchForm = document.getElementById("usl-watch-form");
var watchFn = document.getElementById("usl-watch-fn");
var watchDate = document.getElementById("usl-watch-date");
var watchStatus = document.getElementById("usl-watch-status");
var checkNowBtn = document.getElementById("usl-check-now");

/* ── Guardian timeline helpers (v1.6) ── */
function histOf(t) { return t && t.history && t.history.length ? t.history : []; }
function prevHist(t) { var h = histOf(t); return h.length >= 2 ? h[h.length - 2] : null; }
function fmtTs(ts) {
  if (!ts) return "";
  try {
    return new Date(ts).toLocaleString(undefined,
      { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", hour12: false });
  } catch (e) { return ""; }
}
// Newest entry that actually carried a tail, used for "was ✓ N127UA".
function lastPublished(t) {
  var h = histOf(t);
  for (var i = h.length - 1; i >= 0; i--)
    if ((h[i].status === "yes" || h[i].status === "no") && h[i].tail) return h[i];
  return null;
}
function statusGlyph(s) {
  // "unconfirmed" is "?" on purpose: never "✗" — an unconfirmed aircraft is not
  // a confirmed non-Starlink one (R23 P1-01).
  return s === "yes" ? "✓" : s === "no" ? "✗" : s === "invalid" ? "⚠" : s === "unconfirmed" ? "?" : "⏳";
}

/* v2.4 three-state chip (guard-and-rescue §7.1) — the current state folded into
 * exactly A/B/C, mirroring bg.js notifyState() but keyed off the stored
 * lastStatus (the popup renders state, not a transition). A stale trip whose
 * last check failed reads as C ("Unavailable"), never silently as its old state:
 * the "as of …" note beside it already carries the last-good timestamp. */
function tripState(t) {
  // "stale" = a prior successful check exists but the latest one failed, i.e. an
  // outage/update-unavailable — reason-specifically distinct from a genuine
  // early/unpublished assignment (Codex R23 P1-01). C never collapses an outage,
  // exhausted budget, or bad flight number into "awaiting assignment".
  var stale = !!(t.lastError && t.asOf);
  if (t.lastStatus === "yes") return { key: "a", cls: "usl-chip-a", label: "Starlink ✓" };
  if (t.lastStatus === "no")  return { key: "b", cls: "usl-chip-b", label: "No Starlink ✗" };
  // B-unconfirmed (R23 P1-01): a known aircraft whose Starlink status could not
  // be determined says "Cannot confirm", NEVER "No Starlink" or ✗ — ambiguity
  // is not a negative fact.
  if (t.lastStatus === "unconfirmed")
    return { key: "b", cls: "usl-chip-b", label: "Cannot confirm Starlink" };
  if (t.lastStatus === "early")
    return { key: "c", cls: "usl-chip-c", label: stale ? "Update unavailable" : "Awaiting assignment" };
  if (t.lastStatus === "invalid") return { key: "c", cls: "usl-chip-c", label: "Flight not found" };
  return { key: "c", cls: "usl-chip-c", label: stale ? "Update unavailable" : "Checking…" };
}

// Route back to where the guard was created; carrier fallback when no URL was
// captured. Mirrors bg.js routeBackUrl() (§5). Never fabricates a deep link.
function tripBackUrl(t) {
  if (t && typeof t.sourceUrl === "string" && /^https:\/\//.test(t.sourceUrl)) return t.sourceUrl;
  return /^AS/.test(t && t.fn || "") ? "https://www.alaskaair.com/" : "https://www.united.com/";
}

function tripLine(t) {
  var prev = prevHist(t);
  var swapped = prev && prev.tail && t.tail && prev.tail !== t.tail;
  if (t.lastStatus === "yes") {
    if (swapped && prev.status === "yes")
      return { cls: "usl-t-swap", txt: "✓ swapped, still ✓ — tail " + t.tail + " (was " + prev.tail + ")" };
    return { cls: "usl-t-yes", txt: "✓ Starlink confirmed — tail " + (t.tail || "?") };
  }
  if (t.lastStatus === "no") {
    var alt = t.alts && t.alts[0];
    var better = alt ? " · better: " + alt.flights + " (" + alt.pct + "%)" : "";
    if (swapped && prev.status === "yes")
      return { cls: "usl-t-no", txt: "✗ swap lost Starlink — " + t.tail + " (" + (t.equip || "non-Starlink") + ")" + better };
    if (swapped && prev.status === "no")
      return { cls: "usl-t-swap", txt: "✗ swapped, still ✗ — " + t.tail + " (" + (t.equip || "non-Starlink") + ")" + better };
    return { cls: "usl-t-no", txt: "✗ " + (t.equip || "non-Starlink tail") + better };
  }
  if (t.lastStatus === "unconfirmed")
    return { cls: "usl-t-early", txt: "? tail " + (t.tail || "?") + " assigned, Starlink unconfirmed" };
  if (t.lastStatus === "early") {
    var was = lastPublished(t);
    if (was)
      return { cls: "usl-t-swap", txt: "⏳ assignment withdrawn — was " + statusGlyph(was.status) + " " + was.tail };
    return { cls: "usl-t-early", txt: "⏳ " + (t.prob != null ? "~" + t.prob + "% · " : "") +
      (t.typeDerived ? "odds derived from aircraft type · " : "") + "tail publishes ~48h out" };
  }
  if (t.lastStatus === "invalid")
    return { cls: "usl-t-no", txt: "⚠ flight number not recognized" +
      ((t.invalidCount || 0) >= 2 ? " — checks paused" : "") };
  return { cls: "usl-t-early", txt: "… not checked yet" };
}

function renderHistory(t) {
  var h = histOf(t);
  if (!h.length) return null;
  var wrap = el("div", "usl-hist");
  for (var i = h.length - 1; i >= 0; i--) {
    var e = h[i], before = i > 0 ? h[i - 1] : null;
    var detail = e.tail || (e.prob != null ? "~" + e.prob + "%" : "—");
    var swap = before && before.tail && e.tail && before.tail !== e.tail ? " (swap)" : "";
    wrap.appendChild(el("div", "usl-hist-row",
      "▸ " + fmtTs(e.ts) + "  " + statusGlyph(e.status) + " " + detail + swap));
  }
  return wrap;
}

function renderTrips(trips) {
  tripsEl.innerHTML = "";
  if (!trips.length) {
    var e = el("div", "usl-empty", "No guarded trips. Add one below, or click the ☆ next to any badge on united.com or alaskaair.com.");
    e.style.padding = "4px 2px";
    tripsEl.appendChild(e);
    return;
  }
  trips.sort(function (a, b) { return a.date < b.date ? -1 : 1; });
  trips.forEach(function (t) {
    var row = el("div", "usl-trip-row");
    var left = el("div", "usl-trip-left");
    var main = el("div", "usl-trip-main", t.fn + " · " + t.date + (t.routeSeen || t.route ? " · " + (t.routeSeen || t.route).replace("-", "→") : ""));
    // Route-back link — opens where the guard was created (or the carrier).
    // stopPropagation so it doesn't also toggle the row's history expander.
    var back = el("a", "usl-trip-back", "Open booking ↗");
    back.href = tripBackUrl(t);
    back.target = "_blank";
    back.rel = "noopener";
    back.title = "Open the booking surface you guarded from";
    back.addEventListener("click", function (e) { e.stopPropagation(); });
    main.appendChild(back);
    left.appendChild(main);
    var line = tripLine(t);
    // v2.4 three-state chip, prepended to the detail line.
    var st = tripState(t);
    var sub = el("div", "usl-trip-sub " + line.cls);
    var chip = el("span", "usl-chip " + st.cls, st.label);
    sub.appendChild(chip);
    sub.appendChild(document.createTextNode(line.txt));
    // Stale data: last check failed, so say when the state was last confirmed.
    if (t.lastError && t.asOf) sub.appendChild(el("span", "usl-asof", "as of " + fmtTs(t.asOf)));
    left.appendChild(sub);
    var hist = renderHistory(t);
    if (hist) {
      hist.style.display = "none";
      left.appendChild(hist);
      left.title = "Click for this trip's tail history";
      left.addEventListener("click", function (h) {
        return function () { h.style.display = h.style.display === "none" ? "" : "none"; };
      }(hist));
    }
    var x = el("button", "usl-trip-x", "×");
    x.title = "Stop guarding";
    x.addEventListener("click", function () {
      chrome.runtime.sendMessage({ type: "tripRemove", fn: t.fn, date: t.date }, function (res) {
        void chrome.runtime.lastError;
        if (res && res.trips) renderTrips(res.trips);
      });
    });
    row.appendChild(left);
    row.appendChild(x);
    tripsEl.appendChild(row);
  });
}
/* ══ v3.0 settings (Codex round 26) ═══════════════════════════════════════════
 * Reads and writes the same three keys the content script reads. Defaults are
 * applied ONLY when a key is genuinely absent, so what the popup renders always
 * equals what a page will do — the gate asserts that a fresh profile's stored
 * defaults, the rendered settings state, and first-paint behaviour agree.
 * `chrome.storage.onChanged` in content.js applies a change to open tabs at
 * once, so turning single-carrier sorting off restores the booking site's order
 * immediately rather than at the next reload. */
function initSettings() {
  var single = document.getElementById("usl-set-single");
  var mixP = document.getElementById("usl-set-mixed-preserve");
  var mixQ = document.getElementById("usl-set-mixed-prioritize");
  var mBoth = document.getElementById("usl-set-m-both");
  var mNg = document.getElementById("usl-set-m-ng");
  var mSt = document.getElementById("usl-set-m-st");
  if (!single || !mixP || !mBoth) return;
  chrome.storage.local.get(["uslSortSingle", "uslSortMixed", "uslMetrics"], function (v) {
    void chrome.runtime.lastError;
    single.checked = v.uslSortSingle === undefined ? true : !!v.uslSortSingle;
    var mixed = v.uslSortMixed === "prioritize" ? "prioritize" : "preserve";
    mixP.checked = mixed === "preserve";
    mixQ.checked = mixed === "prioritize";
    var met = ["both", "nextgen", "streaming"].indexOf(v.uslMetrics) >= 0 ? v.uslMetrics : "both";
    mBoth.checked = met === "both";
    mNg.checked = met === "nextgen";
    mSt.checked = met === "streaming";
  });
  single.addEventListener("change", function () {
    chrome.storage.local.set({ uslSortSingle: single.checked });
  });
  [mixP, mixQ].forEach(function (r) {
    r.addEventListener("change", function () {
      if (!r.checked) return;
      // Turning mixed-carrier prioritization off also clears the legacy
      // per-session flag, so an old stored `true` cannot resurrect a reorder
      // the traveller has just switched off.
      var o = { uslSortMixed: r.value };
      if (r.value === "preserve") o.uslPrioritize = false;
      chrome.storage.local.set(o);
    });
  });
  [mBoth, mNg, mSt].forEach(function (r) {
    r.addEventListener("change", function () {
      if (r.checked) chrome.storage.local.set({ uslMetrics: r.value });
    });
  });
}
try { initSettings(); } catch (e) {}

function loadTrips() {
  chrome.runtime.sendMessage({ type: "tripList" }, function (res) {
    void chrome.runtime.lastError;
    if (res && res.trips) renderTrips(res.trips);
  });
}
watchForm.addEventListener("submit", function (e) {
  e.preventDefault();
  var fn = (watchFn.value || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  // Bare digits inherit the airline currently selected above.
  if (/^\d{1,4}$/.test(fn)) fn = airline() + fn;
  if (!/^(?:UA|AS)\d{1,4}$/.test(fn)) { watchStatus.textContent = "Enter a flight like UA1812 or AS1."; return; }
  if (!watchDate.value) { watchStatus.textContent = "Pick a date."; return; }
  watchStatus.textContent = "Adding + checking…";
  chrome.runtime.sendMessage({ type: "tripAdd", fn: fn, date: watchDate.value }, function (res) {
    void chrome.runtime.lastError;
    // The service worker owns the rules (past date, max trips) — surface its text.
    watchStatus.textContent = res && res.ok === false && res.error ? res.error : "";
    if (!res || res.ok !== false) watchFn.value = "";
    if (res && res.trips) renderTrips(res.trips);
  });
});
checkNowBtn.addEventListener("click", function () {
  watchStatus.textContent = "Checking all watched flights…";
  chrome.runtime.sendMessage({ type: "tripCheckNow" }, function (res) {
    void chrome.runtime.lastError;
    watchStatus.textContent = "";
    if (res && res.trips) renderTrips(res.trips);
  });
});
var wd = new Date(Date.now() + 2 * 864e5);
watchDate.value = wd.toISOString().slice(0, 10);
loadTrips();
